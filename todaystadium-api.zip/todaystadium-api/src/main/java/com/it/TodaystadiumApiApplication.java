package com.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodaystadiumApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodaystadiumApiApplication.class, args);
	}

}
